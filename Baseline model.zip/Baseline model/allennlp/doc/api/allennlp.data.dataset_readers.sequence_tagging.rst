allennlp.data.dataset_readers.sequence_tagging
==============================================

.. automodule:: allennlp.data.dataset_readers.sequence_tagging
   :members:
   :undoc-members:
   :show-inheritance:
