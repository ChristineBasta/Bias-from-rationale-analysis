allennlp.modules.span_pruner
=========================================

.. automodule:: allennlp.modules.span_pruner
   :members:
   :undoc-members:
   :show-inheritance:
