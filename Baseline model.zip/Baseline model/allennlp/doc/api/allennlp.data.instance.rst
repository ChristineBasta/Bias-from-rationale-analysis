allennlp.data.instance
======================

.. automodule:: allennlp.data.instance
   :members:
   :undoc-members:
   :show-inheritance:
