allennlp.models.model
=========================================

.. automodule:: allennlp.models.model
   :members:
   :undoc-members:
   :show-inheritance:
