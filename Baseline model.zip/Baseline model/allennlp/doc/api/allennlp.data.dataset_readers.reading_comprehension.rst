allennlp.data.dataset_readers.reading_comprehension
===================================================

.. automodule:: allennlp.data.dataset_readers.reading_comprehension
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.data.dataset_readers.reading_comprehension.squad
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.data.dataset_readers.reading_comprehension.triviaqa
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.data.dataset_readers.reading_comprehension.util
   :members:
   :undoc-members:
   :show-inheritance:
