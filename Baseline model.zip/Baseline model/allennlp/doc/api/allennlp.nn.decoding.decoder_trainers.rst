allennlp.nn.decoding.decoder_trainers
=====================================

.. automodule:: allennlp.nn.decoding.decoder_trainers.decoder_trainer
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.nn.decoding.decoder_trainers.maximum_marginal_likelihood
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.nn.decoding.decoder_trainers.expected_risk_minimization
   :members:
   :undoc-members:
   :show-inheritance:
