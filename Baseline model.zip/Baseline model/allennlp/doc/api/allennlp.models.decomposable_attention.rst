allennlp.models.decomposable_attention
=========================================

.. automodule:: allennlp.models.decomposable_attention
   :members:
   :undoc-members:
   :show-inheritance:
