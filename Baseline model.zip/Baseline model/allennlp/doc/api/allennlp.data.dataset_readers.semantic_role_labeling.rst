allennlp.data.dataset_readers.semantic_role_labeling
====================================================

.. automodule:: allennlp.data.dataset_readers.semantic_role_labeling
   :members:
   :undoc-members:
   :show-inheritance:
