allennlp.commands.evaluate
==========================

.. automodule:: allennlp.commands.evaluate
