allennlp.modules.conditional_random_field
=========================================

.. automodule:: allennlp.modules.conditional_random_field
   :members:
   :show-inheritance:
