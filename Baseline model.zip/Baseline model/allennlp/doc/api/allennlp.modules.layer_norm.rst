allennlp.modules.layer_norm
=========================================

.. automodule:: allennlp.modules.layer_norm
   :members:
   :undoc-members:
   :show-inheritance:
