allennlp.data.dataset_readers.nlvr
==================================

.. automodule:: allennlp.data.dataset_readers.nlvr
   :members:
   :undoc-members:
   :show-inheritance:
