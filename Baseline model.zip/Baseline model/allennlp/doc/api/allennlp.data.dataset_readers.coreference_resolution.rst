allennlp.data.dataset_readers.coreference_resolution
====================================================

.. automodule:: allennlp.data.dataset_readers.coreference_resolution.conll
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.data.dataset_readers.coreference_resolution.winobias
   :members:
   :undoc-members:
   :show-inheritance:
