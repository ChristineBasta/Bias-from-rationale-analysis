allennlp.models.reading_comprehension
=====================================

.. automodule:: allennlp.models.reading_comprehension
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.models.reading_comprehension.bidaf
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.models.reading_comprehension.bidaf_ensemble
   :members:
   :undoc-members:
   :show-inheritance:
