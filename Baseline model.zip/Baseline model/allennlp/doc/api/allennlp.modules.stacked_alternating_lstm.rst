allennlp.modules.stacked_alternating_lstm
=========================================

.. automodule:: allennlp.modules.stacked_alternating_lstm
   :members:
   :undoc-members:
   :show-inheritance:
