allennlp.data.dataset_readers.dataset_reader
============================================

.. automodule:: allennlp.data.dataset_readers.dataset_reader
   :members:
   :undoc-members:
   :show-inheritance:
