allennlp.service.permalinks
=================================

.. automodule:: allennlp.service.permalinks
   :members:
   :undoc-members:
   :show-inheritance:
