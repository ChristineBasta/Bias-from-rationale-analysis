allennlp.modules.matrix_attention
=========================================

.. automodule:: allennlp.modules.matrix_attention
   :members:
   :undoc-members:
   :show-inheritance:
