allennlp.semparse.type_declarations
========================================

.. automodule:: allennlp.semparse.type_declarations
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.type_declarations.type_declaration
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.type_declarations.wikitables_type_declaration
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.type_declarations.nlvr_type_declaration
   :members:
   :undoc-members:
   :show-inheritance:
