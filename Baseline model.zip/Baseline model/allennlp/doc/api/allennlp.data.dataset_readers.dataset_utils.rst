allennlp.data.dataset_readers.dataset_utils
===========================================

.. automodule:: allennlp.data.dataset_readers.dataset_utils.ontonotes
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.data.dataset_readers.dataset_utils.span_utils
   :members:
   :undoc-members:
   :show-inheritance: