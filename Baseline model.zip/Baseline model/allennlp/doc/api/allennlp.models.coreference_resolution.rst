allennlp.models.coreference_resolution
======================================

.. automodule:: allennlp.models.coreference_resolution
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.models.coreference_resolution.coref
   :members:
   :undoc-members:
   :show-inheritance:
