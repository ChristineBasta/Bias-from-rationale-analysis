allennlp.semparse.contexts
==========================

.. automodule:: allennlp.semparse.contexts
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.contexts.knowledge_graph
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.semparse.contexts.table_question_knowledge_graph
   :members:
   :undoc-members:
   :show-inheritance:
