allennlp.modules.span_extractors
================================

.. automodule:: allennlp.modules.span_extractors
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.modules.span_extractors.span_extractor
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.modules.span_extractors.endpoint_span_extractor
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.modules.span_extractors.self_attentive_span_extractor
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: allennlp.modules.span_extractors.bidirectional_endpoint_span_extractor
   :members:
   :undoc-members:
   :show-inheritance:
