allennlp.models.simple_tagger
=========================================

.. automodule:: allennlp.models.simple_tagger
   :members:
   :undoc-members:
   :show-inheritance:
