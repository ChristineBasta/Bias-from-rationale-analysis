allennlp.models.semantic_role_labeler
=========================================

.. automodule:: allennlp.models.semantic_role_labeler
   :members:
   :undoc-members:
   :show-inheritance:
