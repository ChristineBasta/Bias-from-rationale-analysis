#!/usr/bin/env bash
# Run type checking over the python code.

./scripts/verify.py --checks mypy
