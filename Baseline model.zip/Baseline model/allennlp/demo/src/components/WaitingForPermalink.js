import React from 'react';

class WaitingForPermalink extends React.Component {

    render() {
        // TODO(joelgrus): come up with a better "waiting" component.
        return (<div>WAITING</div>);
    }
}

export default WaitingForPermalink;
