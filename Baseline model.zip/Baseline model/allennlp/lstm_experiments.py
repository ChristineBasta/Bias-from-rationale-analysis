import os, sys

config_path = 'training_config/'
data_path = '../.allennlp/datasets/'
# dev_file = data_path + 'rt_test.txt'
dev_file = '../bcn_output/yelp/test.txt'
# dev_file = '../.allennlp/datasets/sst_test'
# dev_file = 'https://s3-us-west-2.amazonaws.com/allennlp/datasets/sst/dev.txt'#data_path + 'squad_dev'

server = 'yelp_lstm'
remove = True
remove = False

# option = 'predict'
option = 'evaluate'
# option = 'train' 
config = config_path + 'lstm.json'
output_path = data_path + server #+ '_WAG'

model_file = output_path + '/'+'model.tar.gz'




run_command = 'python -m allennlp.run ' + option + ' ' 
# run_command = 'python -m allennlp.run ' #+ config + ' ' + output_path + ' ' 
if option == 'evaluate': 
	run_command += model_file + ' '
	run_command += ' --evaluation-data-file '
	run_command += dev_file
	remove = False

else: 
	if remove: os.system('rm -r '+ output_path)
	run_command += config + ' -s ' + ' ' + output_path #+ ' --recover '


print(run_command)
os.system(run_command)

